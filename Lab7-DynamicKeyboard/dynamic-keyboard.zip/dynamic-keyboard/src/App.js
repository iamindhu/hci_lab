import logo from './logo.svg';
import './App.css';
import Main  from './Components/MainComponent';

function App() {
  return (
   <Main/>
  );
}

export default App;
