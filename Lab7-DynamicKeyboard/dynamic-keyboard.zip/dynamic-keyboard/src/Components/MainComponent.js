import React, { Component } from "react";
import { render } from "react-dom";
import Keyboard from "react-simple-keyboard";
import "react-simple-keyboard/build/css/index.css";
import { list, num } from "./layouts";
 import "./main.css";

class Main extends Component {
   
  state = {
    layoutName: "default",
    input: "",
    index: Math.floor(Math.random() * list.length)
  };
  
  
  commonKeyboardOptions = {
    onChange: input => this.onChange(input),
    onKeyPress: button => this.onKeyPress(button),
    theme: "simple-keyboard hg-theme-default hg-layout-default",
    physicalKeyboardHighlight: true,
    newLineOnEnter: true,
    syncInstanceInputs: true,
    mergeDisplay: true,
    debug: false
  };

  keyboardOptions = {
    ...this.commonKeyboardOptions,

    layout: {
      default: list[this.state.index]['default'],
      shift: list[this.state.index]['shift']
    },
    display: {
      "{escape}": "esc ",
      "{tab}": "tab ⇥",
      "{backspace}": "←   backspace",
      "{enter}": "enter ↵",
      "{capslock}": "caps lock",
      "{shiftleft}": "shift ↑",
      "{shiftright}": "shift ↑",
      "{controlleft}": "ctrl ",
      "{controlright}": "ctrl ",
      "{altleft}": "alt ",
      "{altright}": "alt ",
      "{metaleft}": "cmd ",
      "{metaright}": "cmd "
    }
  };

  keyboardControlPadOptions = {
    ...this.commonKeyboardOptions,
    layout: {
      default: [
        "{prtscr} {scrolllock} {pause}",
        "{insert} {home} {pageup}",
        "{delete} {end} {pagedown}"
      ]
    }
  };

  keyboardArrowsOptions = {
    ...this.commonKeyboardOptions,
    layout: {
      default: ["{arrowup}", "{arrowleft} {arrowdown} {arrowright}"]
    }
  };

  keyboardNumPadOptions = {
    ...this.commonKeyboardOptions,
    layout: {
      default: num[this.state.index]['default']
    }
  };

  keyboardNumPadEndOptions = {
    ...this.commonKeyboardOptions,
    layout: {
      default: ["{numpadsubtract}", "{numpadadd}", "{numpadenter}"]
    }
  };

  onChange = input => {
    this.setState({
      input: input
    });
    console.log("Input changed", input);
  };

  onKeyPress = button => {
    console.log("Button pressed", button);


    if (
      button === "{shift}" ||
      button === "{shiftleft}" ||
      button === "{shiftright}" ||
      button === "{capslock}"
    ) {
      this.handleShift();
    }
  };

  handleShift = () => {
    let layoutName = this.state.layoutName;

    this.setState({
      layoutName: layoutName === "default" ? "shift" : "default"
    });
  };

  onChangeInput = event => {
    let input = event.target.value;
    this.setState(
      {
        input: input
      },
      () => {
        this.keyboard.setInput(input);
      }
    );
  };

  render() {
    console.log(`index: ${this.state.index}`);
    return (
      <div>
        <textarea
          value={this.state.input}
          rows= "7"
          cols="200"
          placeholder={"Tap on the virtual keyboard to start"}
          onChange={e => this.onChangeInput(e)}
        />
        <div className={"keyboardContainer"}>
          <Keyboard
            baseClass={"simple-keyboard-main"}
            keyboardRef={r => (this.keyboard = r)}
            layoutName={this.state.layoutName}
            {...this.keyboardOptions}
          />

          <div className="controlArrows">
            <Keyboard
              baseClass={"simple-keyboard-control"}
              {...this.keyboardControlPadOptions}
            />
            <Keyboard
              baseClass={"simple-keyboard-arrows"}
              {...this.keyboardArrowsOptions}
            />
          </div>

          {/* <div className="numPad">
            <Keyboard
              baseClass={"simple-keyboard-numpad"}
              {...this.keyboardNumPadOptions}
            />
            <Keyboard
              baseClass={"simple-keyboard-numpadEnd"}
              {...this.keyboardNumPadEndOptions}
            />
          </div> */}
        </div>
      </div>
    );
  }
}

 export default Main;