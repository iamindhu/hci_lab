function getRandomNumbers() {
    let list = [[1,'!'],[2,'@'],[3,'#'],[4,'$'],[5,'%'], [6,'^'], [7,'&'], [8,'*'], [9,'('],[0,')']] 
    list = list.sort(() => Math.random() - 0.5)
    return list;
}
function getRandomAlphabets(){
    let list2 = [['a','A'],['b','B'],['c','C'],['d','D'],['e','E'], ['f','F'], ['g','G'],['h','H'],['i','I'],['j','J'],['k','K'],['l','L'],['m','M'],['n','N'],['o','O'],['p','P'],['q','Q'],['r','R'],['s','S'],['t','T'],['u','U'],['v','V'],['w','W'],['x','X'],['y','Y'],['z','Z']]
    list2 = list2.sort(() => Math.random() - 0.5)
    return list2;
}
function getRandomFunctions(){
    let list3 = ['f1','f2','f3','f4','f5','f6','f7','f8','f9','f10','f11','f12']
    list3 = list3.sort(() => Math.random() - 0.5)
    return list3;
}

var rand = new Array(10); 
for (var i = 0; i < 10; i++) {
  rand[i] = new Array(2); // make each element an array
}
rand = getRandomNumbers.call();

var rand_alpha = new Array(26);
for (var i = 0; i < 26; i++) {
  rand_alpha[i] = new Array(2); // make each element an array
}
rand_alpha = getRandomAlphabets.call();

var rand_func = new Array(12);
rand_func = getRandomFunctions.call();

exports.list =  [ 
{
    //qwerty normal keyboard
    'default' : [
        "{escape} {f1} {f2} {f3} {f4} {f5} {f6} {f7} {f8} {f9} {f10} {f11} {f12}",
        "` 1 2 3 4 5 6 7 8 9 0 - = {backspace}",
        "{tab} q w e r t y u i o p [ ] \\",
        "{capslock} a s d f g h j k l ; ' {enter}",
        "{shiftleft} z x c v b n m , . / {shiftright}",
        "{controlleft} {altleft} {metaleft} {space} {metaright} {altright}"
    ],
    'shift': [
        "{escape} {f1} {f2} {f3} {f4} {f5} {f6} {f7} {f8} {f9} {f10} {f11} {f12}",
        "~ ! @ # $ % ^ & * ( ) _ + {backspace}",
        "{tab} Q W E R T Y U I O P { } |",
        '{capslock} A S D F G H J K L : " {enter}',
        "{shiftleft} Z X C V B N M < > ? {shiftright}",
        "{controlleft} {altleft} {metaleft} {space} {metaright} {altright}"
    ]
},

{
    
    'default' : [
        `{escape} ${rand_func[0]} ${rand_func[1]} ${rand_func[2]} ${rand_func[3]} ${rand_func[4]} ${rand_func[5]} ${rand_func[6]} ${rand_func[7]} ${rand_func[8]} ${rand_func[9]} ${rand_func[10]} ${rand_func[11]}`,
        `\u00B4 ${rand[0][0]} ${rand[1][0]} ${rand[2][0]} ${rand[3][0]} ${rand[4][0]} ${rand[5][0]} ${rand[6][0]} ${rand[7][0]} ${rand[8][0]} ${rand[9][0]} - = {backspace}`,
        `{tab} ${rand_alpha[0][0]} ${rand_alpha[1][0]} ${rand_alpha[2][0]} ${rand_alpha[3][0]} ${rand_alpha[4][0]} ${rand_alpha[5][0]} ${rand_alpha[6][0]} ${rand_alpha[7][0]} ${rand_alpha[8][0]} ${rand_alpha[9][0]} [ ] \\`,
        `{capslock} ${rand_alpha[10][0]} ${rand_alpha[11][0]} ${rand_alpha[12][0]} ${rand_alpha[13][0]} ${rand_alpha[14][0]} ${rand_alpha[15][0]} ${rand_alpha[16][0]} ${rand_alpha[17][0]} ${rand_alpha[18][0]} ; ' {enter}`,
        `{shiftleft} ${rand_alpha[19][0]} ${rand_alpha[20][0]} ${rand_alpha[21][0]} ${rand_alpha[22][0]} ${rand_alpha[23][0]} ${rand_alpha[24][0]} ${rand_alpha[25][0]} , . / {shiftright}`,
        "{controlleft} {altleft} {metaleft} {space} {metaright} {altright}"
    ],
    'shift': [
        "{escape} {f1} {f2} {f3} {f4} {f5} {f6} {f7} {f8} {f9} {f10} {f11} {f12}",
        `~ ${rand[0][1]} ${rand[1][1]} ${rand[2][1]} ${rand[3][1]} ${rand[4][1]} ${rand[5][1]} ${rand[6][1]} ${rand[7][1]} ${rand[8][1]} ${rand[9][1]} _ + {backspace}`,
        `{tab} ${rand_alpha[0][1]} ${rand_alpha[1][1]} ${rand_alpha[2][1]} ${rand_alpha[3][1]} ${rand_alpha[4][1]} ${rand_alpha[5][1]} ${rand_alpha[6][1]} ${rand_alpha[7][1]} ${rand_alpha[8][1]} ${rand_alpha[9][1]} { } |`,
        `{capslock} ${rand_alpha[10][1]} ${rand_alpha[11][1]} ${rand_alpha[12][1]} ${rand_alpha[13][1]} ${rand_alpha[14][1]} ${rand_alpha[15][1]} ${rand_alpha[16][1]} ${rand_alpha[17][1]} ${rand_alpha[18][1]} : " {enter}`,
        `{shiftleft} ${rand_alpha[19][1]} ${rand_alpha[20][1]} ${rand_alpha[21][1]} ${rand_alpha[22][1]} ${rand_alpha[23][1]} ${rand_alpha[24][1]} ${rand_alpha[25][1]} < > ? {shiftright}`,
        "{controlleft} {altleft} {metaleft} {space} {metaright} {altright}"
    ]

}

]

exports.num = [
    {
        'default': [
            "{numlock} {numpaddivide} {numpadmultiply}",
            "{numpad7} {numpad8} {numpad9}",
            "{numpad4} {numpad5} {numpad6}",
            "{numpad1} {numpad2} {numpad3}",
            "{numpad0} {numpaddecimal}"
          ]
    },
    {
        'default': [
            "{numlock} {numpaddivide} {numpadmultiply}",
            "{numpad1} {numpad4} {numpad8}",
            "{numpad5} {numpad2} {numpad7}",
            "{numpad9} {numpad6} {numpad3}",
            "{numpad0} {numpaddecimal}"
          ]
    },
    {
        'default': [
            "{numlock} {numpaddivide} {numpadmultiply}",
            "{numpad0} {numpad1} {numpad2}",
            "{numpad3} {numpad4} {numpad5}",
            "{numpad6} {numpad7} {numpad8}",
            "{numpad9} {numpaddecimal}"
          ]
    },
    {
        'default': [
            "{numlock} {numpaddivide} {numpadmultiply}",
            "{numpad1} {numpad2} {numpad3}",
            "{numpad8} {numpad9} {numpad4}",
            "{numpad7} {numpad6} {numpad5}",
            "{numpad0} {numpaddecimal}"
          ]
    },
    {
        'default': [
            "{numlock} {numpaddivide} {numpadmultiply}",
            "{numpad4} {numpad5} {numpad6}",
            "{numpad1} {numpad8} {numpad3}",
            "{numpad7} {numpad2} {numpad9}",
            "{numpad0} {numpaddecimal}"
          ]
    }
]